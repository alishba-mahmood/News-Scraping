<template>
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
   
   
          <a class="navbar-brand" href="#">Navbar</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
           <img src="../assets/newsbyte.png" alt="Logo" class="logo-image" style="width:2.5cm; padding-right:1cm;  "      />
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item"  style="margin-right: 15px;">
                <router-link :to="{ name: 'Categories-Guardian', params: { category: 'technology' }}" class="custom-link">Technology</router-link>
             </li>

              <li class="nav-item"  style="margin-right: 15px;">
                <router-link :to="{ name: 'Categories-Guardian', params: { category: 'sport' }}" class="custom-link">Sports</router-link>
              </li>
  
              <li class="nav-item"  style="margin-right: 15px;">
                <router-link :to="{ name: 'Categories-Guardian', params: { category: 'environment' }}" class="custom-link">Health</router-link>
              </li>

              <li class="nav-item"  style="margin-right: 15px;">
                <router-link :to="{ name: 'Categories-Guardian', params: { category: 'uk-news' }}" class="custom-link">Business</router-link>
              </li>
              
              <li class="nav-item"  style="margin-right: 15px;">
                <router-link :to="{ name: 'Categories-Guardian', params: { category: 'film' }}" class="custom-link">Entertainment</router-link>
              </li>
   
            </ul>

          </div>
        </div>
      </nav>
   
    <h1></h1>
     <NewsCard
                                     v-if="category !== ''"
                                     :newsItems="newsItems"
                                     :category="category"
                                     :rowsCount="rowsCount" :displayInCol="displayInCol"
                                   >
                                   </NewsCard>
   
   
   </template>
   
   <script>
import NewsService from "../services/NewsService";
import NewsCard from "./NewsCard";
   
   export default {
     name: 'Categories-Guardian',
     data() {
       return {
               newsItems: [],
                category: '',
                rowsCount:0,
                displayInCol:0,
   
       };
     },
   
      components:{
        NewsCard,
   
      },
      mounted() {
         this.category = this.$route.params.category;
       },

      // created() {
      // console.log("i am generic card");
      // this.getNewsByCategoryGuardian(this.category);
      //    },
   
   watch: {
    '$route.params.category': {
      handler(newCategory) {
        if (newCategory !== this.category) {
          this.category = newCategory;
          this.getNewsByCategoryGuardian(newCategory);
        }
      },
      immediate: true, // Trigger on initial load
    },
  },
  methods: {

           
            getNewsByCategoryGuardian(category) {
           this.category=category;
             NewsService.getNewsByCategoryGuardian(this.category)
               .then((response) => {

                console.log("i am generic card after response: "+this.category);
                 this.newsItems = response.data;
                 console.log(this.newsItems)
            this.firstHalfItems();
   
               })
               .catch((error) => {
                 console.error("Error fetching data:", error);
               });
           },
           firstHalfItems() {
      this.displayInCol = this.newsItems.length / 3;
      this.rowsCount = Math.floor((this.newsItems.length - this.displayInCol)/ 3);
  
      if ((this.newsItems.length - this.displayInColumn) % 3 != 0) {
        this.displayInCol += (this.newsItems.length - this.displayInCol) % 3;
        
      }
  
    },
   
         },
   
   };
   </script>
   <style scoped>.navbar {
                     margin-top: -1.5cm;
                     background-color: black;
   
                 }
   
                 #item {
                     color: white;
                     font-size: 21px;
                     font-family: Major Mono Display;
                     padding-left: 1cm;
                     outline:none;
                     background-color: transparent;
                     border: none;
                     text-decoration: none;
                     cursor: pointer;
                 }
   .container {
       display: flex;
       flex-direction: column;
       justify-content: space-between;
       height: 100vh;
   }
   
   .up-div, .down-div {
       height: 50%;
       padding: 10px;
   }
   
   .card-link {
     text-decoration: none;
     color: black;
   }
   #card {
     width: 22cm;
     height: 24cm;
     border-radius: 0cm;
     border: none;
     margin-bottom: 1cm;
   }
   
   #img {
     height: 17cm;
     border-radius: 0cm;
   }
   
   #title {
   font-family: 'Tahoma';
    font-size:19px;
   }
   
   .divider {
     border-top: 2px solid #ddd; 
     margin-top: 1cm;
   }
   
   </style>