<template>
<div id="img2" >
<nav class="navbar navbar-expand-lg ">
  <div class="container-fluid">
    <img src="../assets/newsbyte.png" alt="Logo" class="logo-image" style="width:4.5cm;  padding-left:3cm;  "      />

    <a class="navbar-brand" href="#" id="item">News Byte</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>


    <div class="collapse navbar-collapse" id="navbarScroll">
      <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#" id="item">About Us</a>
        </li>


        <li class="nav-item">
          <a class="nav-link disabled" aria-disabled="true" id="item">More</a>
        </li>
      </ul>
     <li class="nav-item dropdown" id="dropdown">
              <a class="nav-link dropdown-toggle"  id="item" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                National News
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item"  href="HomePage92">92 News</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item"   href="#">Dawn News</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="HomePageAry" >ARY News</a></li>
                 <li><hr class="dropdown-divider"></li>
                 <li><a class="dropdown-item" href="#" >The Nation News</a></li>
              </ul>
            </li>
              <li class="nav-item dropdown" id="dropdown2">
              <a class="nav-link dropdown-toggle"  id="item" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                International News
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item"  href="HomePageGuardian">The Guardian</a></li>
                    <li><hr class="dropdown-divider"></li>



                <li><a class="dropdown-item"   href="#">NewYork Times</a></li>
               </ul>
            </li>
    </div>
  </div>
</nav>
</div>
<footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-logo">
<h2>News Byte</h2>
  </div>
               <a href="#" id="tex" >LogIn as Admin</a>
                <div class="footer-social">
                    <ul>
                        <li><a href="#" id="tex" ><img src="facebook-icon.png" alt="Facebook"></a></li>
                        <li><a href="#" id="tex" ><img src="twitter-icon.png" alt="Twitter"></a></li>
                        <li><a href="#" id="tex" > <img src="instagram-icon.png" alt="Instagram"></a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-text">
                &copy; 2023 NewsByte. All rights reserved.
            </div>
        </div>
    </footer>
</template>

<script>

export default {
  name: "WelcomePage", 
 
};
</script>



<style>
#img2{

  background-image: url('../assets/main2.png'); background-size: cover;
  background-position: center;
  background-repeat: no-repeat; 
  width:50.8cm; 
 height:28cm;
}
.navbar {
                  margin-top: -1.5cm;
                  background-color: black;

              }

              #item {
                  color: white;
                  font-size: 21px;
                  font-family: Major Mono Display;
                  padding-left: 1cm;
                  outline:none;
                  background-color: transparent;
                  border: none;
                  text-decoration: none;
                  cursor: pointer;
              }

#dropdown{
margin-right:1cm;

}
#dropdown2{
margin-right:2cm;

}
/* Basic styling for the footer */
.footer {
    background-color: #333; /* Background color for the footer */
    color: #fff; /* Text color for the footer */
    padding: 30px 0; /* Padding for the top and bottom of the footer */
}

/* Center the content inside the footer
.container {
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
} */

/* Style for the footer logo */
.footer-logo a {
    font-size: 24px;
    font-weight: bold;
    text-decoration: none;
    color: #fff;
}

/* Style for the footer links */
.footer-links ul {
    list-style-type: none;
    padding: 0;
}

.footer-links ul li {
    display: inline;
    margin-right: 20px;
}

.footer-links ul li a {
    text-decoration: none;
    color: #fff;
}
#tex{
    text-decoration: none;
    color: #fff;
}


/* Style for the footer social icons */
.footer-social ul {
    list-style-type: none;
    padding: 0;
}

.footer-social ul li {
    display: inline;
    margin-right: 20px;
}

.footer-social ul li a img {
    width: 30px;
    height: 30px;
    border-radius: 50%;
}

/* Style for the copyright notice */
.footer-text {
    margin-top: 20px;
    font-size: 14px;
    opacity: 0.7;
}


</style>
