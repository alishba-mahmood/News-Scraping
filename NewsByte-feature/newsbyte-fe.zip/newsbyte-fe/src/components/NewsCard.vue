<template>
<div class="container container-fluid" style="margin-top:20px;">

  <div class="row">
    <h3 style="text-align: left; color:#000; font-family: Georgia, serif;">{{category}}</h3>
    <hr style="border: none;
            border-top: 4px solid black;
            margin-bottom: 10px 0; 
            color:#000">
  </div>
  <div class="row">

    <div class="col-8">
        <div class="row" v-for="i in rowsCount" :key="i">
          <div class="col" v-for="j in 3" :key="j">
              <a :href="newsItems[((i-1)*3)+(j-1)].url" style="text-decoration: none;">
                  <div class="card text-center" style="border: none;">
                    <div v-if="newsItems[((i-1)*3)+(j-1)].urlToImage != null">
                      <img class="card-img-top" :src="newsItems[((i-1)*3)+(j-1)].urlToImage" alt="Card image cap" style="max-height: 50%;">
                      <p>pic index not null{{ newsItems[((i-1)*3)+(j-1)].urlToImage }}</p>
                    </div>
                    <div v-if="newsItems[((i-1)*3)+(j-1)].urlToImage == null">
                      <img class="card-img-top" :src="getCardImage(((i-1)*3)+(j-1))" alt="Card image cap" style="max-height: 50%;">
                      <p></p>
                    </div>
                   
                      <div class="card-body">
                          <p class="text-md">{{ newsItems[((i-1)*3)+(j-1)].title }}</p>
                          <p class="text-md"><strong>{{ newsItems[((i-1)*3)+(j-1)].publishedAt }}</strong></p>
                      </div>
                  </div>
              </a>
          </div>
        </div>
    </div>

    <div class="col-3" style="margin-left: 40px; border-left: 1px solid #000;">
  <div v-for="i in displayInCol" :key="i">
    <a :href="newsItems[(rowsCount*3)+(i-1)].url" style="text-decoration: none;">
      <div class="row">
        <div class="col-6">
          <div v-if="newsItems[(rowsCount*3)+(i-1)].urlToImage != null">
              <img class="card-img-top" :src="newsItems[(rowsCount*3)+(i-1)].urlToImage" alt="Card image cap" style="max-height: 50%;">
          </div>
          <div v-if="newsItems[(rowsCount*3)+(i-1)].urlToImage == null">
              <img class="card-img-top" :src="getCardImage((rowsCount*3)+(i-1))" alt="Card image cap" style="max-height: 50%;">
          </div>
          
        </div>
        <div class="col-6">
          <div>
            <h6 style="color: black;">{{ newsItems[(rowsCount*3)+(i-1)].title }}</h6>
          </div>
        </div>
      </div>
    </a>
    <hr>
  </div>
</div>

  </div>
</div>
</template>

<script>

// import NavFooter92 from "./NavFooter92.vue";
export default {
  name: 'NewsCard',
  created() {
  },
  components: {
    // NavFooter92,
},
  props: {
    newsItems: Array,
    rowsCount: Number,
    displayInCol: Number,
    category: String,
  
  },
  data() {
        return {
        environment: [
                      "/health/1.avif",
                      "/health/2.jpg",
                      "/health/3.jpg",
                      "/health/4.jpg",
                      "/health/5.avif",
                      "/health/6.avif",
                      "/health/7.jpg",
                      "/health/8.webp",
                      "/health/9.png",
                      "/health/10.webp",
                      "/health/11.jpg",
                      "/health/12.JPG",
                      "/health/13.jpeg",
                      "/health/14.jpg",
                      "/health/15.webp",
		                  "/health/16.jpeg",
		                  "/health/17.png",
		                  "/health/18.jpg",
		                  "/health/19.webp",
		                  "/health/20.avif",
		                  "/health/21.jpg",
                      "/health/22.jpg",
		                  "/health/23.webp",
		                  "/health/24.jpg",
		                  "/health/25.jpg",
		                  "/health/26.webp",
	                    "/health/28.jpg",
		                  "/health/29.jpg",
                      "/health/30.jpg",
                     ],

        film: [
        "/media/1.jpg",
        "/media/2.jpg",
        "/media/3.jpg",
        "/media/4.jpg",
        "/media/5.jpg",
        "/media/6.jpg",
        "/media/7.jpg",
        "/media/8.jpg",
        "/media/9.jpg",
        "/media/10.jpg",
        "/media/11.jpg",
        "/media/1.jpg",
        "/media/12.jpg",
        "/media/13.jpg",
        "/media/14.JPG",
        "/media/15.jpg",
	      "/media/16.png",
	      "/media/17.jpeg",
	      "/media/18.jpeg",
	      "/media/19.webp",
	      "/media/20.jpg",
	      "/media/21.jpeg",
	      "/media/22.webp",
	      "/media/23.png",
	      "/media/24.webp",
	      "/media/25.webp",
	      "/media/26.jpg",
	      "/media/27.jpg",
	      "/media/28.jpg",
	      "/media/29.jpeg",
	      "/media/30.avif",
      ],
    sport: [
        "/sports/2.jpg",
        "/sports/3.jpg",
        "/sports/4.jpg",
        "/sports/5.jpg",
        "/sports/6.jpg",
        "/sports/7.jpg",
        "/sports/8.jpg",
        "/sports/9.jpg",
        "/sports/10.jpg",
        "/sports/11.jpeg",
        "/sports/12.jpeg",
        "/sports/13.avif",
        "/sports/14.avif",
        "/sports/15.jpg",
        "/sports/16.jpg",
        "/sports/17.webp",
        "/sports/18.webp",
        "/sports/19.jpg",
        "/sports/20.jpg",
        "/sports/21.jpeg",
        "/sports/22.jpg",
        "/sports/23.jpg",
        "/sports/24.webp",
        "/sports/25.jpeg",
        "/sports/26.png",
        "/sports/27.jpg",
        "/sports/28.jpg",
        "/sports/29.jpeg",
        "/sports/30.jpeg",
      ],

      technical: [
                "/tech/1.jpg",
                "/tech/2.jpg",
                "/tech/3.jpg",
                "/tech/4.jpeg",
                "/tech/5.jpg",
                "/tech/6.jpeg",
                "/tech/7.webp",
                "/tech/8.png",
                "/tech/9.jpeg",
                "/tech/10.jpg",
                "/tech/11.jpg",
                "/tech/12.jpg",
                "/tech/12.webp",
                "/tech/13.webp",
                "/tech/14.jpeg",
                "/tech/15.jpg",
                "/tech/16.jpg",
                "/tech/17.jpg",
                "/tech/18.jpeg",
                "/tech/19.webp",
                "/tech/20.jpg",
                "/tech/21.jpg",
                "/tech/22.jpg",
                "/tech/23.jpg",
                "/tech/24.jpg",
                "/tech/25.jpg",
                "/tech/26.jpg",
                "/tech/27.jpg",
                "/tech/28.jpg",
                "/tech/29.jpg",
                "/tech/30.webp",

              ],
 business: [
        "/business/1.jpg",
        "/business/2.jpeg",
        "/business/3.webp",
        "/business/4.avif",
        "/business/5.webp",
        "/business/6.webp",
        "/business/7.jpg",
        "/business/8.jpg",
        "/business/9.jpg",
        "/business/10.avif",
        "/business/11.png",
        "/business/12.jpg",
        "/business/13.jpg",
        "/business/14.jpg",
        "/business/15.webp",
        "/business/16.jpg",
        "/business/17.jpg",
        "/business/18.avif",
        "/business/19.webp",
        "/business/20.jpg",
        "/business/21.jpg",
        "/business/22.webp",
        "/business/23.jpg",
        "/business/24.jpg",
        "/business/25.jpg",
        "/business/26.jpg",
        "/business/27.webp",
        "/business/28.avif",
        "/business/29.jpg",
        "/business/30.webp",
     ],

        };
      },


    methods: {
   getCardImage(index) {

         if(this.category==="environment"){
         const effectiveIndex = index % this.environment.length;
         return this.environment[effectiveIndex];
       }

        if(this.category==="technology"){
         const effectiveIndex = index % this.technical.length;
         return this.technical[effectiveIndex];
       }

       if(this.category==="sport"){
         const effectiveIndex = index % this.sport.length;
         return this.sport[effectiveIndex];
       }

       if(this.category==="business"){
         const effectiveIndex = index % this.business.length;
         return this.business[effectiveIndex];
       }

       if(this.category==="film"){
         const effectiveIndex = index % this.film.length;
         return this.film[effectiveIndex];
       }
      },

    }

};
</script>

