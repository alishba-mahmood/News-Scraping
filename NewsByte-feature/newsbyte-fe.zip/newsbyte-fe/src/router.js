import HomePage92 from "./components/HomePage92.vue";
import HomePageGuardian from "./components/HomePageGuardian.vue";

import Categories92 from "./components/Categories92.vue";
import CategoriesGuardian from "./components/CategoriesGuardian.vue";

import { createRouter, createWebHistory } from "vue-router";

const routes = [
    {
        name: "HomePage92",
        component: HomePage92,
        path: "/92"
    },
    {
        name: "Categories-92",
        component: Categories92,
        path: '/92/:category',
    },
    {
        name: 'HomePageGuardian',
        component: HomePageGuardian,
        path: '/guardian',
        
    },
    {
        name: "Categories-Guardian",
        component: CategoriesGuardian,
        path: '/guardian/:category',
        
    },
    
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});


export default router;