import WelcomePage from "./components/WelcomePage.vue";

import HomePage92 from "./components/HomePage92.vue";
import HomePageGuardian from "./components/HomePageGuardian.vue";
import HomePageAry from "./components/HomePageAry.vue";
import HomePageNY from "./components/HomePageNY.vue";

import Categories92 from "./components/Categories92.vue";
import CategoriesGuardian from "./components/CategoriesGuardian.vue";
import CategoriesAry from "./components/CategoriesAry.vue";
import CategoriesNY from "./components/CategoriesNY.vue";

import { createRouter, createWebHistory } from "vue-router";

const routes = [
    {
        name: "WelcomePage",
        component: WelcomePage,
        path: "/"
    },
    {
        name: "HomePage92",
        component: HomePage92,
        path: "/92"
    },
    {
        name: "Categories-92",
        component: Categories92,
        path: '/92/:category',
    },
    {
        name: 'HomePageGuardian',
        component: HomePageGuardian,
        path: '/guardian',
        
    },
    {
        name: "Categories-Guardian",
        component: CategoriesGuardian,
        path: '/guardian/:category',
        
    },
    {
        name: 'HomePageAry',
        component: HomePageAry,
        path: '/ary',
        
    },
    {
        name: "Categories-Ary",
        component: CategoriesAry,
        path: '/ary/:category',
        
    },
    {
        name: 'HomePageNY',
        component: HomePageNY,
        path: '/ny',
        
    },
    {
        name: "Categories-NY",
        component: CategoriesNY,
        path: '/ny/:category',
        
    },

    
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});


export default router;