import axios from 'axios';

const GET_NEWS_92 = '/news/92';
const GET_NEWS_GUARDIAN = '/news/guardian';
const GET_NEWS_ARY = '/news/ary';
const GET_NEWS_NY = '/news/nyTimes';

class NewsService{

    getNews92()
    {
        return axios.get(GET_NEWS_92);
    }
    getNewsByCategory92(category)
    {
        return axios.get(`${GET_NEWS_92}/${category}`);
    }

    getNewsGuardian()
    {
        return axios.get(GET_NEWS_GUARDIAN);
    }
    getNewsByCategoryGuardian(category) 
    {
        return axios.get(`${GET_NEWS_GUARDIAN}/${category}`);
    }

    getNewsAry()
    {
        return axios.get(GET_NEWS_ARY);
    }
    getNewsByCategoryAry(category) 
    {
        return axios.get(`${GET_NEWS_ARY}/${category}`);
    }


    getNewsNY()
    {
        return axios.get(GET_NEWS_NY);
    }
    getNewsByCategoryNY(category) 
    {
        console.log("in service: "+axios.get(`${GET_NEWS_NY}/${category}`));
        console.log(`${GET_NEWS_NY}/${category}`);
        return axios.get(`${GET_NEWS_NY}/${category}`);
    }
}

export default new NewsService();