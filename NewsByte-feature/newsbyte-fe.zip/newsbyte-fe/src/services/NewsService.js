import axios from 'axios';

const GET_NEWS_92 = '/news/92';

const GET_NEWS_GUARDIAN = "/news/guardian/uk-news";
const GET_NEWS_GUARDIAN_CATEGORY = "/news/guardian";

class NewsService{

    getNews92()
    {
        console.log(GET_NEWS_92)
        return axios.get(GET_NEWS_92);
    }
    getNewsByCategory92(category)
    {
        console.log(`${GET_NEWS_92}/${category}`)
        return axios.get(`${GET_NEWS_92}/${category}`)
    }

    getNewsGuardian()
    {
        console.log(GET_NEWS_GUARDIAN);
        return axios.get(GET_NEWS_GUARDIAN);
    }
    getNewsByCategoryGuardian(category) 
    {
        console.log("in service : "+category);
        return axios.get(`${GET_NEWS_GUARDIAN_CATEGORY}/${category}`)
    }

}

export default new NewsService();